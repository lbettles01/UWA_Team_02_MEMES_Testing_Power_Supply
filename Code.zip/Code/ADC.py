from smbus2 import SMBus
import time

#-----------------------------------------------------------------------------------------------
#Datasheet of AD7999 available:
#https://www.analog.com/media/en/technical-documentation/data-sheets/AD7991_7995_7999.pdf
#-----------------------------------------------------------------------------------------------
#Configuration Register (D7 - MSB):
#D7  D6  D5  D4  D3      D2   D1              D0
#CH3 CH2 CH1 CH0 REF_SEL FLTR Bit trial delay Sample delay
#Set D2, D1, D0 to 0 to enable filtering, and to ensure no I2C activity occurs during conversion
#-----------------------------------------------------------------------------------------------
#Current Measuring on CH0
#Interlock on CH1
#-----------------------------------------------------------------------------------------------

#Open I2C bus 1
bus = smbus2.SMBus(1)

#Set the AD7999 address 
AD7999_address = 0x0101001 #From data sheet

#Current Measuring: 
def current_send_config(reference):
    #Set the configuration byte
    config_byte = 0b00010000 #CH0 selected
    if(reference == "Supply Voltage"):
        config_byte = config_byte | 0b00001000 #Force D3 to 1
    elif(reference == "External"):
        config_byte = config_byte & 0b11101111 #Force D3 to 0
    
    #Write the configuration byte to the AD7999
    register_address = 0b00000000 # ***What is this??***
    bus.write_byte_data(AD7999_address, register_address, config_byte)

#Will return a number between 0 and 255
def read_current():
    #Read the ADC value from the selected channel - should return 16 bits (1 word)
    register_address = 0b00000000 # ***What is this??***
    adc_value = bus.read_word_data(AD7999_address, register_address)
    #Remove the first 4 and last 4 bits
    adc_value = adc_value >> 4 
    adc_value = adc_value & 0b11111111
    return adc_value

#Put into loop to continuously read
current_send_config("Supply Voltage")
read_current()