##file_name.py #CHange to whatever
import RPi.GPIO as GPIO
import time

class AD9850:
    # Initialise the AD9850 module with GPIO pins and clock frequency
    def __init__(self, w_clk, fq_ud, data, reset, clk_freq=100000000):
        self.w_clk = w_clk #W_CLK on DDS
        self.fq_ud = fq_ud #FQ_UD on DDS
        self.data = data #D7 on DDS
        self.reset = reset #Reset on DDS
        self.clk_freq = clk_freq #Freq of ASEM1
        self.initialise()

    # Function to generate a pulse for clocking data
    def pulse(self, pin):
        GPIO.output(pin, GPIO.HIGH)
        GPIO.output(pin, GPIO.HIGH)
        GPIO.output(pin, GPIO.HIGH) #Three High Necessary For Successful Data Send
        GPIO.output(pin, GPIO.LOW)

    # Initialise GPIO and reset AD9850 module
    def initialise(self):
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.w_clk, GPIO.OUT)
        GPIO.setup(self.fq_ud, GPIO.OUT)
        GPIO.setup(self.data, GPIO.OUT)
        GPIO.setup(self.reset, GPIO.OUT)
        self.pulse(self.reset)
        self.pulse(self.w_clk)
        self.pulse(self.fq_ud)

    # Set the output frequency of the AD9850
    def set_frequency(self, user_frequency, ac_mode_enabled):
        if ac_mode_enabled and 50000 <= user_frequency <= 300000: #50kHz to 300kHz
            freq_word = round(2**32 * user_frequency / self.clk_freq) & 0xFFFFFFFF #32 Bit Data For DDS Chip
        elif not ac_mode_enabled: #DC Mode
            freq_word = 0

        # Send 32-bit frequency word
        for b in range(32):
            GPIO.output(self.data, freq_word & 0x01)
            self.pulse(self.w_clk)
            freq_word >>= 1

        phase_word = 0 #No Phase Required
        for b in range(8):
            GPIO.output(self.data, phase_word & 0x01)
            self.pulse(self.w_clk)
            phase_word >>= 1

        self.pulse(self.fq_ud)

if __name__ == '__main__':
    # Create an instance of the AD9850 class
    ad9850 = AD9850(W_CLK=17, FQ_UD=18, DATA=22, RESET=23) #Change to Actual GPIO values
     
    # Assume user_frequency holds the frequency value entered by the user
    # Assume ac_mode_enabled is a boolean that is True if AC mode is enabled, False otherwise
    user_frequency = float(input("Enter the frequency: "))  # Replace this with the actual method to get user input
    ac_mode_enabled = bool(input("Is AC mode enabled? (True/False): "))  # Replace this with the actual method to get user input
     
    # Set the AD9850 frequency based on user input
    ad9850.set_frequency(user_frequency, ac_mode_enabled)