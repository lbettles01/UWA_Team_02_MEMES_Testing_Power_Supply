##------------ SEARCH FOR '!!' to change stuff where required ------------
# V10 - All GUI is working
# V11 - Adding DDS and Modulation. Add overcurrent input validation. Changed what happens turning on/off device

# Install pygame onto Raspberry Pi first: pip install pygame

# PYGAME DOCUMENTATION 
#https://www.pygame.org/docs/index.html

#------pygame.draw.rect()------
#rect(surface, color, rect, width=0, border_radius=0, border_top_left_radius=-1, 
# border_top_right_radius=-1, border_bottom_left_radius=-1, border_bottom_right_radius=-1) -> Rect
#------pygame.Rect------
#Rect(left, top, width, height) -> Rect
#------fill()------
#fill(color, rect=None, special_flags=0) -> Rect
#------------------------------

import pygame
from pygame.draw import rect as draw_rect
import RPi.GPIO as GPIO
import time
from matrixKeypad_RPi_GPIO import keypad
import decimal
from DDS_frequency_control import AD9850

#-----CONSTANTS-----
#DISPLAYING VALUES BOXES
LENGTH_RES, WIDTH_RES = 800, 480
DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT = 350, 90
DISPLAY_BOX_X_TOP, DISPLAY_BOX_Y_TOP = 40, 80
BOX_MIDDLE_GAP_X, BOX_MIDDLE_GAP_Y = 20, 25

#UPDATING VALUES BOXES
OUTER_BOX_WIDTH, OUTER_BOX_HEIGHT = 720, 364
OUTER_BOX_X_TOP, OUTER_BOX_Y_TOP = 40, 40
VALUE_BOX_WIDTH, VALUE_BOX_HEIGHT = 640, 90
VALUE_BOX_X_TOP, VALUE_BOX1_Y_TOP = 80, 154
VALUE_BOX_Y_GAP = 50
UPDATING_TEXT_Y_GAP = 64

# OUTER_BOX_WIDTH, OUTER_BOX_HEIGHT = 500, 384
# OUTER_BOX_X_TOP, OUTER_BOX_Y_TOP = 150, 40
# VALUE_BOX_WIDTH, VALUE_BOX_HEIGHT = 420, 90
# VALUE_BOX_X_TOP, VALUE_BOX1_Y_TOP = 190, 154
# VALUE_BOX_Y_GAP = 50
# UPDATING_TEXT_Y_GAP = 64
 
#CONFIRMING NEW VALUE BOXES
CON_OUTER_BOX_WIDTH, CON_OUTER_BOX_HEIGHT = 400, 330
CON_OUTER_BOX_X_TOP, CON_OUTER_BOX_Y_TOP = 200, 75
NEW_VALUE_BOX_WIDTH, NEW_VALUE_BOX_HEIGHT = 300, 150
BUTTON_BOX_WIDTH, BUTTON_BOX_HEIGHT = 150, 70
CONFIRM_TEXT_Y_GAP = 60

# PARAMETER SETTINGS
VOLTAGE_DIVISIONS = 0.05 #V
DC_VOLTAGE_MAX = 200 #V
DC_VOLTAGE_INTERLOCK = 100 #V
DC_VOLTAGE_MIN = 0 #V
AC_VOLTAGE_MAX = 200 #V RMS
AC_VOLTAGE_INTERLOCK = 50 #V RMS
AC_VOLTAGE_MIN = 0 #V RMS
SIGNAL_FREQ_DIVISIONS = 100 #Hz
SIGNAL_FREQ_MAX = 300 #kHz
SIGNAL_FREQ_MIN = 50 #kHz
MODULATION_FREQ_DIVISONS = 10 #Hz
MODULATION_FREQ_MAX = 100 #Hz
MODULATION_FREQ_MIN = 10 #Hz
OVERCURRENT_MAX = 10
OVERCURRENT_MIN = 1

#RASPBERRY PI GPIO ASSIGNMENT
PWM_PIN = 18
INITIAL_FREQUENCY = 0
DEVICE_ON_LED = 9
ACDC_CTRL = 27

#Duty cycle in percentage (0-100)
DUTY_CYCLE_OFF = 100 #Produces a constant output
DUTY_CYCLE_ON = 50 #Produces a square wave
#-------------------

#-----VARIABLES-----
voltage_value = 0
frequency_value = 0
voltage_output_type = "AC"
overcurrent_value = 10
output_modulated = "No"
mod_frequency = 0
#-------------------

#-----COLOURS-----
#        (R, G, B)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
YELLOW = (255, 215,  10)
TBLUE = (0, 219, 232)
#-------------------


# Initialize the keypad class
kp = keypad()
 
def digit():
    # Loop while waiting for a keypress
    r = None
    while r == None:
        r = kp.getKey()
    return r 

def set_values_to_default():
    global voltage_value, frequency_value, voltage_output_type, overcurrent_value, output_modulated, mod_frequency
    voltage_value = 0
    frequency_value = 0
    voltage_output_type = "AC"
    overcurrent_value = 10
    output_modulated = "No"
    mod_frequency = 0
    
    GPIO.setmode(GPIO.BCM)
    #Setup LED Pin to output
    GPIO.setup(DEVICE_ON_LED, GPIO.OUT)
    #Set LED to OFF state
    GPIO.output(DEVICE_ON_LED, GPIO.LOW)
    #Setup ACDC_CTROL Pin to output
    GPIO.setup(ACDC_CTRL, GPIO.OUT)

#Sets initial frequency output of modulator to 0 Hz
def setup_PWM_signal():
    global pwm
    GPIO.setmode(GPIO.BCM)
    # Set up the PWM on the specified pin
    GPIO.setup(PWM_PIN, GPIO.OUT)
    pwm = GPIO.PWM(PWM_PIN, INITIAL_FREQUENCY)
    # Start PWM with the initial duty cycle - initially, want the signal to not be modulated, so have it off.
    pwm.start(DUTY_CYCLE_OFF)

#Turn device off/idle during the updating of values and initial startup of device
def turn_device_off():
    #!! set voltage = 0 

    #!! Turn off Modulation 
    pwm.ChangeDutyCycle(DUTY_CYCLE_OFF)
    #Set LED to OFF state
    GPIO.output(18, GPIO.LOW)

#Turn device on after every update occurs
def turn_device_on():
    global voltage_value, frequency_value, voltage_output_type, overcurrent_value, output_modulated, mod_frequency
    #!! Voltage
    #!!check interlock engaged
        #set voltage = current set voltage
        #AC: 0-200
        #DC: 0-200Vrms
    #if not engaged
        #AC: 0-50Vrms
        #DC: 0-100V

    #Setting AD9850 signal frequency and ACDC control
    #Multiply frequency_value by 1000 to get it in Hz
    if(voltage_output_type == "AC"):
        ad9850.set_frequency(frequency_value*1000, True)
        GPIO.output(ACDC_CTRL, GPIO.HIGH)
    elif(voltage_output_type == "DC"):
        ad9850.set_frequency(frequency_value*1000, False)
        GPIO.output(ACDC_CTRL, GPIO.LOW)

    #Change Modulation Frequency/Output
    pwm.ChangeFrequency(float(mod_frequency))
    if(output_modulated == "Yes"):
        pwm.ChangeDutyCycle(DUTY_CYCLE_ON)
    elif(output_modulated == "No"):
        pwm.ChangeDutyCycle(DUTY_CYCLE_OFF)
    
    #!!leave overcurrent?
    #Set LED to ON state
    GPIO.output(18,GPIO.HIGH)

#Checks if voltage entered by user is valid
#Returns 0 - Voltage entered is valid
#Returns 1 - Voltage entered is not a multiple of 0.05
#Returns 2 - Voltage entered is above AC Max or below AC Min
#Returns 3 - Voltage entered is above DC Max or below DC Min
def is_valid_voltage(voltage, voltage_type):
    valid = 0
    with decimal.localcontext() as ctx:
        ctx.prec = 10
        division = decimal.Decimal(voltage) / decimal.Decimal(VOLTAGE_DIVISIONS)
    if(division % 1 != 0):
        valid = 1
    elif(voltage_type == "AC"):
        if(float(voltage) > AC_VOLTAGE_MAX or float(voltage) < AC_VOLTAGE_MIN):
            valid = 2
    elif(voltage_type == "DC"):
        if(float(voltage) > DC_VOLTAGE_MAX or float(voltage) < DC_VOLTAGE_MIN):
            valid = 3
    return valid

#Checks if frequency entered by user is valid
#Returns 0 - Frequency entered is valid
#Returns 1 - Modulation Frequency entered is not a multiple of 10
#Returns 2 - Modulation Frequency entered is above Max or below Min
#Returns 3 - Signal Frequency entered is is not a multiple of 100
#Returns 4 - Signal Frequency entered is above Max or below Min
def is_valid_frequency(frequency, is_mod_freq):
    valid = 0
    #Modulation Frequency
    if(is_mod_freq):
        if((int(frequency) % MODULATION_FREQ_DIVISONS) != 0):
            valid = 1
        elif(int(frequency) > MODULATION_FREQ_MAX or int(frequency) < MODULATION_FREQ_MIN):
            valid = 2
    #Signal Frequency
    else:
        if(((float(frequency) * 1000) % SIGNAL_FREQ_DIVISIONS) != 0):
            valid = 3
        elif(float(frequency) > SIGNAL_FREQ_MAX or float(frequency) < SIGNAL_FREQ_MIN):
            valid = 4
    return valid

# !! Does this take decimal values??? If so need to check divisions
#Checks if overcurrent value entered by user is valid
#Returns 0 - Overucrrent value is valid
#Returns 1 - Overcurrent value is above Max or below Min
def is_valid_overcurrent(overcurrent_value):
    valid = 0
    if(overcurrent_value > OVERCURRENT_MAX or overcurrent_value < OVERCURRENT_MIN):
        valid = 1
    return valid

# Function for printing text in a specific place with a specific colour
def text_xy_centered(text, container_x_start, container_y_start, text_colour, container_width, container_height):
    label = font.render(str(text), 1, (text_colour))
    xpo_new = int((container_width - label.get_width())/2) + container_x_start
    ypo_new = int((container_height - label.get_height())/2) + container_y_start
    screen.blit(label,(xpo_new, ypo_new))

def text_x_centered(text, container_x_start, container_y_start, text_colour, container_width):
    label = font.render(str(text), 1, (text_colour))
    xpo_new = int((container_width - label.get_width())/2) + container_x_start
    screen.blit(label,(xpo_new, container_y_start))

def text_y_centered(text, container_x_start, container_y_start, text_colour, container_height):
    label = font.render(str(text), 1, (text_colour))
    ypo_new = int((container_height - label.get_height())/2) + container_y_start
    screen.blit(label,(container_x_start, ypo_new))

#Use this function to display the currently selected item to edit
def display_values(text_colours, border_colours, current_value, display):
    global font
    # Clear the screen
    screen.fill(BLACK)
    
    #Outer screen border
    draw_rect(screen, TBLUE, pygame.Rect(0, 0, LENGTH_RES, WIDTH_RES), 3)
    #Title text
    title_text = ""
    if(display):
        title_text = "Signal Currently Generated with these Parameters"
    else:
        title_text = "Updating Parameters - No Signal Currently Generated"
    font = pygame.font.Font(None, 45)
    text_x_centered(title_text, 0, 20, YELLOW, LENGTH_RES)
    font = pygame.font.Font(None, 36)

    #Rectangles for the values
    draw_rect(screen, border_colours[0], pygame.Rect(DISPLAY_BOX_X_TOP, DISPLAY_BOX_Y_TOP, DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT), 3)
    draw_rect(screen, border_colours[1], pygame.Rect(DISPLAY_BOX_X_TOP, DISPLAY_BOX_Y_TOP + DISPLAY_BOX_HEIGHT + BOX_MIDDLE_GAP_Y, \
                                         DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT), 3)
    draw_rect(screen, border_colours[2], pygame.Rect(DISPLAY_BOX_X_TOP, DISPLAY_BOX_Y_TOP + 2 * DISPLAY_BOX_HEIGHT + 2 * BOX_MIDDLE_GAP_Y, \
                                          DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT), 3)
    draw_rect(screen, border_colours[3], pygame.Rect(DISPLAY_BOX_X_TOP + DISPLAY_BOX_WIDTH + BOX_MIDDLE_GAP_X, \
                                          DISPLAY_BOX_Y_TOP, DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT), 3)
    draw_rect(screen, border_colours[4], pygame.Rect(DISPLAY_BOX_X_TOP + DISPLAY_BOX_WIDTH + BOX_MIDDLE_GAP_X, \
                                          DISPLAY_BOX_Y_TOP + DISPLAY_BOX_HEIGHT + BOX_MIDDLE_GAP_Y, DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT), 3)
    draw_rect(screen, border_colours[5], pygame.Rect(DISPLAY_BOX_X_TOP + DISPLAY_BOX_WIDTH + BOX_MIDDLE_GAP_X, \
                                          DISPLAY_BOX_Y_TOP + 2 * DISPLAY_BOX_HEIGHT + 2 * BOX_MIDDLE_GAP_Y, DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT), 3)

    #Display content in center of rectangles
    voltage_text = "Voltage: " + str(voltage_value) + " V"
    frequency_text = "Frequency: " + str(frequency_value) + " kHz"
    overcurrent_text = "Overcurrent: " + str(overcurrent_value) + " mA"
    voltage_output_type_text = "Voltage Type: " + voltage_output_type
    output_modulated_text = "Output Modulated: " + output_modulated
    mod_frequency_text = "Modulation Freq: " + str(mod_frequency) + " Hz"

    #Voltage Box (top left)
    text_xy_centered(voltage_text, DISPLAY_BOX_X_TOP, DISPLAY_BOX_Y_TOP, text_colours[0], DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT)
    #Frequency Box (middle left)
    text_xy_centered(frequency_text, DISPLAY_BOX_X_TOP, DISPLAY_BOX_Y_TOP + DISPLAY_BOX_HEIGHT + BOX_MIDDLE_GAP_Y, \
                     text_colours[1], DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT)
    #Overcurrent Box (bottom left)
    text_xy_centered(overcurrent_text, DISPLAY_BOX_X_TOP, DISPLAY_BOX_Y_TOP + 2 * DISPLAY_BOX_HEIGHT + 2 * BOX_MIDDLE_GAP_Y, \
                     text_colours[2], DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT)
    #Voltage Output Type Box (top right)
    text_xy_centered(voltage_output_type_text, DISPLAY_BOX_X_TOP + DISPLAY_BOX_WIDTH + BOX_MIDDLE_GAP_X, \
                      DISPLAY_BOX_Y_TOP, text_colours[3], DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT)
    #Output Modulated Box (middle right)
    text_xy_centered(output_modulated_text, DISPLAY_BOX_X_TOP + DISPLAY_BOX_WIDTH + BOX_MIDDLE_GAP_X, \
                       DISPLAY_BOX_Y_TOP + DISPLAY_BOX_HEIGHT + BOX_MIDDLE_GAP_Y, text_colours[4], DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT)
    #Modulation Frequency Box (bottom right)
    text_xy_centered(mod_frequency_text, DISPLAY_BOX_X_TOP + DISPLAY_BOX_WIDTH + BOX_MIDDLE_GAP_X, \
                       DISPLAY_BOX_Y_TOP + 2 * DISPLAY_BOX_HEIGHT + 2 * BOX_MIDDLE_GAP_Y, text_colours[5], DISPLAY_BOX_WIDTH, DISPLAY_BOX_HEIGHT)

    #Update the values text
    value_text = ""
    if(display):
        value_text = "Press '*' to update values"
    else:
        value_text = "Press '*' to stop udpating"
    label = font.render(str(value_text), 1, (YELLOW))
    y_val = WIDTH_RES - label.get_height() - 10
    screen.blit(label,(20, y_val))
    
    #Display the arrows
    if(current_value == 0):
        text_xy_centered(">>", 0, DISPLAY_BOX_Y_TOP, RED, DISPLAY_BOX_X_TOP, DISPLAY_BOX_HEIGHT)
    elif(current_value == 1):
        text_xy_centered(">>", 0, DISPLAY_BOX_Y_TOP + DISPLAY_BOX_HEIGHT + BOX_MIDDLE_GAP_Y, RED, \
                         DISPLAY_BOX_X_TOP, DISPLAY_BOX_HEIGHT)
    elif(current_value == 2):
        text_xy_centered(">>", 0, DISPLAY_BOX_Y_TOP + 2 * DISPLAY_BOX_HEIGHT + 2 * BOX_MIDDLE_GAP_Y, RED, \
                         DISPLAY_BOX_X_TOP, DISPLAY_BOX_HEIGHT)
    elif(current_value == 3):
        text_xy_centered("<<", LENGTH_RES - DISPLAY_BOX_X_TOP, DISPLAY_BOX_Y_TOP, RED, DISPLAY_BOX_X_TOP, DISPLAY_BOX_HEIGHT)
    elif(current_value == 4):
        text_xy_centered("<<", LENGTH_RES - DISPLAY_BOX_X_TOP, DISPLAY_BOX_Y_TOP + DISPLAY_BOX_HEIGHT + BOX_MIDDLE_GAP_Y, \
                          RED, DISPLAY_BOX_X_TOP, DISPLAY_BOX_HEIGHT)
    elif(current_value == 5):
        text_xy_centered("<<", LENGTH_RES - DISPLAY_BOX_X_TOP, DISPLAY_BOX_Y_TOP + 2 * DISPLAY_BOX_HEIGHT + 2 * BOX_MIDDLE_GAP_Y, \
                          RED, DISPLAY_BOX_X_TOP, DISPLAY_BOX_HEIGHT)

def display_editing_screen(updating, current_value_text):
    screen.fill(BLACK)
    #Outer screen border
    draw_rect(screen, TBLUE, pygame.Rect(0, 0, LENGTH_RES, WIDTH_RES), 3)
    #Outer Box
    draw_rect(screen, TBLUE, pygame.Rect(OUTER_BOX_X_TOP, OUTER_BOX_Y_TOP, OUTER_BOX_WIDTH, OUTER_BOX_HEIGHT), 3)
    #2 Inner Value Boxes
    draw_rect(screen, TBLUE, pygame.Rect(VALUE_BOX_X_TOP, VALUE_BOX1_Y_TOP, VALUE_BOX_WIDTH, VALUE_BOX_HEIGHT), 3)
    draw_rect(screen, TBLUE, pygame.Rect(VALUE_BOX_X_TOP, VALUE_BOX1_Y_TOP + VALUE_BOX_Y_GAP + VALUE_BOX_HEIGHT, \
                                          VALUE_BOX_WIDTH, VALUE_BOX_HEIGHT), 3)

    #Updating text
    text_xy_centered("Updating " + updating, OUTER_BOX_X_TOP, OUTER_BOX_Y_TOP, YELLOW, OUTER_BOX_WIDTH, UPDATING_TEXT_Y_GAP)
    #Current value text
    text_xy_centered("Current Value:", OUTER_BOX_X_TOP, OUTER_BOX_Y_TOP + UPDATING_TEXT_Y_GAP, YELLOW, OUTER_BOX_WIDTH, VALUE_BOX_Y_GAP)
    #Current value text
    text_xy_centered(current_value_text, OUTER_BOX_X_TOP + int((OUTER_BOX_WIDTH - VALUE_BOX_WIDTH)/2), \
                     OUTER_BOX_Y_TOP + UPDATING_TEXT_Y_GAP + VALUE_BOX_Y_GAP, YELLOW, VALUE_BOX_WIDTH, VALUE_BOX_HEIGHT)
    #New value text
    text_xy_centered("New Value:", OUTER_BOX_X_TOP, \
                      OUTER_BOX_Y_TOP + UPDATING_TEXT_Y_GAP + VALUE_BOX_Y_GAP + VALUE_BOX_HEIGHT, YELLOW, OUTER_BOX_WIDTH, VALUE_BOX_Y_GAP)

    #Text at bottom
    bottom_text = "Press '*' to go back"
    label = font.render(str(bottom_text), 1, (YELLOW))
    y_val = WIDTH_RES - label.get_height() - 10
    screen.blit(label,(20, y_val))

def display_error_msg(err_msg):
    label = font.render(str(err_msg), 1, (RED))
    y_val = WIDTH_RES - label.get_height() - 10
    x_val = LENGTH_RES - label.get_width() - 20
    screen.fill(BLACK, pygame.Rect(int(LENGTH_RES/2), y_val-10, int(LENGTH_RES/2)-10, label.get_height()+15))
    screen.blit(label,(x_val, y_val))
    pygame.display.flip()

def display_entered_value(entered_value):
    screen.fill(BLACK, pygame.Rect(OUTER_BOX_X_TOP + int((OUTER_BOX_WIDTH - VALUE_BOX_WIDTH)/2) + 10, \
                                            OUTER_BOX_Y_TOP + UPDATING_TEXT_Y_GAP + 2 * VALUE_BOX_Y_GAP + VALUE_BOX_HEIGHT + 10, \
                                                VALUE_BOX_WIDTH - 20, VALUE_BOX_HEIGHT - 20))
    text_xy_centered(entered_value, OUTER_BOX_X_TOP + int((OUTER_BOX_WIDTH - VALUE_BOX_WIDTH)/2), \
                OUTER_BOX_Y_TOP + UPDATING_TEXT_Y_GAP + 2 * VALUE_BOX_Y_GAP + VALUE_BOX_HEIGHT, YELLOW, \
                VALUE_BOX_WIDTH, VALUE_BOX_HEIGHT)

#New screen display to confirm if the entered value is what the user wants to update 
#the variable with
def confirm_new_value(new_value, updating_text):
    screen.fill(BLACK)
    #Outer screen border
    draw_rect(screen, TBLUE, pygame.Rect(0, 0, LENGTH_RES, WIDTH_RES), 3)
    #Outer Box
    draw_rect(screen, TBLUE, pygame.Rect(CON_OUTER_BOX_X_TOP, CON_OUTER_BOX_Y_TOP, CON_OUTER_BOX_WIDTH, CON_OUTER_BOX_HEIGHT), 3)
    #Display New Value Box
    draw_rect(screen, TBLUE, pygame.Rect(CON_OUTER_BOX_X_TOP + int((CON_OUTER_BOX_WIDTH - NEW_VALUE_BOX_WIDTH)/2), \
                                        CONFIRM_TEXT_Y_GAP + CON_OUTER_BOX_Y_TOP, NEW_VALUE_BOX_WIDTH, NEW_VALUE_BOX_HEIGHT), 3)
    #Cancel Box
    draw_rect(screen, TBLUE, pygame.Rect(CON_OUTER_BOX_X_TOP + 20, WIDTH_RES - CON_OUTER_BOX_Y_TOP - 20 - BUTTON_BOX_HEIGHT, \
                                        BUTTON_BOX_WIDTH, BUTTON_BOX_HEIGHT), 3)
    #Confirm Box
    draw_rect(screen, TBLUE, pygame.Rect(LENGTH_RES - CON_OUTER_BOX_X_TOP - 20 - BUTTON_BOX_WIDTH, WIDTH_RES - CON_OUTER_BOX_Y_TOP - 20 - BUTTON_BOX_HEIGHT, \
                                        BUTTON_BOX_WIDTH, BUTTON_BOX_HEIGHT), 3)

    #Confirm New Value Text
    text_xy_centered("Confirm New Value", CON_OUTER_BOX_X_TOP, CON_OUTER_BOX_Y_TOP, YELLOW, CON_OUTER_BOX_WIDTH, CONFIRM_TEXT_Y_GAP)
    #Value Being Updated Text
    text_xy_centered(updating_text, CON_OUTER_BOX_X_TOP + int((CON_OUTER_BOX_WIDTH - NEW_VALUE_BOX_WIDTH)/2), \
                    CONFIRM_TEXT_Y_GAP + CON_OUTER_BOX_Y_TOP, YELLOW, NEW_VALUE_BOX_WIDTH, int(NEW_VALUE_BOX_HEIGHT/2))
    #Actual New Value
    text_xy_centered(new_value, CON_OUTER_BOX_X_TOP + int((CON_OUTER_BOX_WIDTH - NEW_VALUE_BOX_WIDTH)/2), \
                    CONFIRM_TEXT_Y_GAP + CON_OUTER_BOX_Y_TOP + int(NEW_VALUE_BOX_HEIGHT/2), YELLOW, NEW_VALUE_BOX_WIDTH, int(NEW_VALUE_BOX_HEIGHT/2))
    #Cancel Text
    text_xy_centered("Cancel(C)", CON_OUTER_BOX_X_TOP + 20, WIDTH_RES - CON_OUTER_BOX_Y_TOP - 20 - BUTTON_BOX_HEIGHT, \
                     YELLOW, BUTTON_BOX_WIDTH, BUTTON_BOX_HEIGHT)
    #Confirm Text
    text_xy_centered("Confirm(D)", LENGTH_RES - CON_OUTER_BOX_X_TOP - 20 - BUTTON_BOX_WIDTH, WIDTH_RES - CON_OUTER_BOX_Y_TOP - 20 - BUTTON_BOX_HEIGHT, \
                      YELLOW, BUTTON_BOX_WIDTH, BUTTON_BOX_HEIGHT)
    pygame.display.flip()

    confirmation = True
    waiting = True
    time.sleep(0.5)
    while(waiting):        
        user_pressed = digit()
        if(user_pressed == "D"):
            confirmation = True
            waiting = False
        elif(user_pressed == "C"):
            confirmation = False
            waiting = False
    return confirmation

def set_new_value(current_value):
    updating = ""
    current_value_text = ""
    global voltage_value, frequency_value, overcurrent_value, voltage_output_type, output_modulated, mod_frequency
    if(current_value == 0):
        current_value_text = str(voltage_value) + " V"
        updating = "Voltage Value"
    elif(current_value == 1):
        current_value_text = str(frequency_value) + " kHz"
        updating = "Signal Frequency"
    elif(current_value == 2):
        current_value_text = str(overcurrent_value) + " mA"
        updating = "Overcurrent Protection Value"
    elif(current_value == 3):
        current_value_text = voltage_output_type
        updating = "Voltage Output Type"
    elif(current_value == 4):
        current_value_text = output_modulated
        updating = "Signal Modulation"
    elif(current_value == 5):
        current_value_text = str(mod_frequency) + " Hz"
        updating = "Modulation Freq"

    display_editing_screen(updating, current_value_text)
    pygame.display.flip()

    voltage_output_type_temp = voltage_output_type
    output_modulated_temp = output_modulated

    new_value = ""
    waiting = True
    time.sleep(0.5)
    while(waiting):        
        user_pressed = digit()
        #Go back to updating page
        if(user_pressed == "*"):
            waiting = False
        elif(user_pressed == "D"):
            if(len(new_value) != 0):
                confirmation = False
                voltage_err = 0
                sig_frequency_err = 0
                mod_frequency_err = 0
                overcurrent_err = 0
                #Checking voltage entered is in 0.05V increments 
                #!! do we need for frequency?
                if(current_value == 0):
                    voltage_err = is_valid_voltage(new_value, voltage_output_type)
                    if(voltage_err == 0):
                        confirmation = confirm_new_value(new_value, updating)
                elif(current_value == 1):
                    sig_frequency_err = is_valid_frequency(new_value, False)
                    if(sig_frequency_err == 0):
                        confirmation = confirm_new_value(new_value, updating)
                elif(current_value == 2):
                    overcurrent_err = is_valid_overcurrent(new_value)
                    if(overcurrent_err == 0):
                        confirmation = confirm_new_value(new_value, updating)
                elif(current_value == 5):
                    mod_frequency_err = is_valid_frequency(new_value, True)
                    if(mod_frequency_err == 0):
                        confirmation = confirm_new_value(new_value, updating)
                else:
                    confirmation = confirm_new_value(new_value, updating)
                if(confirmation):
                    if(current_value == 0):
                        voltage_value = float(new_value)
                    elif(current_value == 1):
                        frequency_value = float(new_value)
                    elif(current_value == 2):
                        overcurrent_value = float(new_value)
                    elif(current_value == 3):
                        voltage_output_type = new_value
                    elif(current_value == 4):
                        output_modulated = new_value
                    elif(current_value == 5):
                        mod_frequency = new_value
                    waiting = False
                else:
                    #User pressed cancel on Confirm New Value page, so back to editing page
                    display_editing_screen(updating, current_value_text)
                    # !! Change the parameter entered into this function to include the units, where required
                    # if(current_value = 0):
                    #   display_entered_value(new_value + " V"))
                    # elif(current_value = 1):
                    #   display_entered_value(new_value + " kHz")  
                    # elif(current_value = 2):
                    #   display_entered_value(new_value + " mA")       
                    # elif(current_value = 5):
                    #   display_entered_value(new_value + " Hz")                       
                    display_entered_value(new_value)
                    #Voltage Input Errors
                    if(voltage_err == 1):
                        display_error_msg("ERROR: Use 0.05V increments")
                    elif(voltage_err == 2):
                        display_error_msg("ERROR: Voltage not between " + str(AC_VOLTAGE_MIN) + "-" + str(AC_VOLTAGE_MAX) + "V")
                    elif(voltage_err == 3):
                        display_error_msg("ERROR: Voltage not between " + str(DC_VOLTAGE_MIN) + "-" + str(DC_VOLTAGE_MAX) + "V")
                    #Overcurrent Input Errors
                    if(overcurrent_err == 1):
                        display_error_msg("ERROR: Overcurrent not between " + str(OVERCURRENT_MIN) + "-" + str(OVERCURRENT_MAX) + "mA")
                    #Modulation Frequency Input Errors
                    elif(mod_frequency_err == 1):
                        display_error_msg("ERROR: Use 10Hz increments")
                    elif(mod_frequency_err == 2):
                        display_error_msg("ERROR: Frequency not between " + str(MODULATION_FREQ_MIN) + "-" + str(MODULATION_FREQ_MAX) + "Hz")
                    #Signal Frequency Input Errors
                    elif(sig_frequency_err == 3):
                        display_error_msg("ERROR: Use 100Hz increments")
                    elif(sig_frequency_err == 4):
                        display_error_msg("ERROR: Frequency not between " + str(SIGNAL_FREQ_MIN) + "-" + str(SIGNAL_FREQ_MAX) + "kHz")
                    pygame.display.flip()
            else:
                display_error_msg("ERROR: No value entered")
        #Values requiring numeric inputs
        elif(current_value in [0, 1, 2, 5]):
            # 'C' is backspace
            if(user_pressed == "C"):
                if(len(new_value) == 1):
                    new_value = ""
                elif(len(new_value) > 1):
                    new_value = new_value[:-1]
                screen.fill(BLACK, pygame.Rect(VALUE_BOX_X_TOP+10, VALUE_BOX1_Y_TOP + VALUE_BOX_Y_GAP + VALUE_BOX_HEIGHT+10, \
                                               VALUE_BOX_WIDTH-20, VALUE_BOX_HEIGHT-20))
            elif(user_pressed in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]):
                new_value = new_value + str(user_pressed)
            #Add a decimal - only for voltage values (Frequency should be entered in Hz)
            elif(user_pressed == "#" and current_value in [0, 1]):
                new_value = new_value + "."
        #Non-numeric inputs
        #Voltage output type
        # !! Make it scroll between Yes and No
        elif(current_value == 3):
            if(voltage_output_type_temp == "DC"):
                if(user_pressed == "A" or user_pressed == "B"):
                    new_value = "AC"
                    voltage_output_type_temp = "AC"
            elif(voltage_output_type == "AC"):
                if(user_pressed == "A" or user_pressed == "B"):
                    new_value = "DC"
                    voltage_output_type_temp = "DC"
        #Signal Modulation
        elif(current_value == 4):
            if(output_modulated_temp == "Yes"):
                if(user_pressed == "A" or user_pressed == "B"):
                    new_value = "No"
                    output_modulated_temp = "No"
            elif(output_modulated_temp == "No"):
                if(user_pressed == "A" or user_pressed == "B"):
                    new_value = "Yes"
                    output_modulated_temp = 'Yes'
        #display text
        if(user_pressed != "D"):
            display_entered_value(new_value)
        pygame.display.flip()
        time.sleep(0.3)

#Use this function to update the values
def update_values():
    #Can go between 0 and 5
    current_value = 0
    text_colours = [YELLOW, YELLOW, YELLOW, YELLOW, YELLOW, YELLOW]
    border_colours = [TBLUE, TBLUE, TBLUE, TBLUE, TBLUE, TBLUE]
        
    text_colours[current_value] = RED
    border_colours[current_value] = RED
    display_values(text_colours, border_colours, current_value, display=False)
    pygame.display.flip()
    time.sleep(0.1)
    waiting = True
    while(waiting):
        text_colours = [YELLOW, YELLOW, YELLOW, YELLOW, YELLOW, YELLOW]
        border_colours = [TBLUE, TBLUE, TBLUE, TBLUE, TBLUE, TBLUE]
        
        user_pressed = digit()
        if(user_pressed == "*"):
            waiting = False
        #Go up
        elif(user_pressed == "A"):
            if current_value > 0:
                current_value = current_value - 1
            else:  
                current_value = 5
                
            text_colours[current_value] = RED
            border_colours[current_value] = RED
            
            display_values(text_colours, border_colours, current_value, display=False)
            time.sleep(0.3)
        #Go down
        elif(user_pressed == "B"):
            if current_value < 5:
                current_value = current_value + 1
            else:  
                current_value = 0
                
            text_colours[current_value] = RED
            border_colours[current_value] = RED
            
            display_values(text_colours, border_colours, current_value, display=False)
            time.sleep(0.3)
        #Enter
        elif(user_pressed == "D"):
            set_new_value(current_value)
            text_colours[current_value] = RED
            border_colours[current_value] = RED
            display_values(text_colours, border_colours, current_value, display=False)
            pass
        pygame.display.flip()
        time.sleep(0.1)


#------------------------------------START PROGRAM---------------------------------------
GPIO.setmode(GPIO.BCM)
#Set all device settings to default
set_values_to_default()
#Setup the PWM signal
setup_PWM_signal()
#Create an instance of the AD9850 class
ad9850 = AD9850(w_clk=22, fq_ud=23, data=24, reset=25) 

#Initially set to updating information on the screen
#!! Change this
updating_values = False
displaying_values = True

#Initialize pygame and the screen
pygame.init()
screen = pygame.display.set_mode((LENGTH_RES, WIDTH_RES))
#screen = pygame.display.set_mode((LENGTH_RES, WIDTH_RES), pygame.FULLSCREEN)
font = pygame.font.Font(None, 36)

#Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    #Update or Display the values on screen
    if(updating_values):
        turn_device_off() #Does't change the values codewise, just sets device values to off/idle
        update_values()
        updating_values = False
        displaying_values = True
    elif(displaying_values):
        text_colours = [YELLOW, YELLOW, YELLOW, YELLOW, YELLOW, YELLOW]
        border_colours = [TBLUE, TBLUE, TBLUE, TBLUE, TBLUE, TBLUE]
        display_values(text_colours, border_colours, current_value=None, display=True)
        turn_device_on()
        pygame.display.flip()
        user_input = digit()
        if(user_input == "*"):
            updating_values = True
            displaying_values = False
        if(user_input == "#"):
            updating_values = True
            displaying_values = False
            running = False
 
    #Reduce CPU utilisation
    time.sleep(0.1)

#Quit pygame
pygame.quit()
